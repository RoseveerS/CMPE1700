//*********************************
// Roseveer Salh - 200463801
//*********************************
#include<stdlib.h>
#include<stdio.h>

int main(int argc, char** argv)
{
	//if user does not enter 2 argument
	if (argc != 2)
	{
		//display error message and exit
		printf("Must have 2 arguments");
		printf("\nUsage: file.exe, arg1");
		exit(EXIT_FAILURE);
	}

	unsigned int numBits = atoi(argv[1]);	//user input for number to calculate
	unsigned int currentBit = 0;			//used to determine if a new run has been created
	double average = 0;						//average number of runs
	double nCount = 0;						//used to count number of runs in the binary number
	double totRun = 0;						//total number of runs found in the binary number

	//iterate through all numbers in value given
	for (int nIterate = 0; nIterate < (1 << numBits) + 1; nIterate++)
	{
		//iterate through all bits in the value
		for (int i = 0; i < numBits; i++)
		{
			//count number of runs if bit changes from a 0 to 1
			if (nIterate & 1 << i && currentBit == 0)
			{
				currentBit = 1;
				nCount++;
			}

			else
			{
				//change current bit to a 0 if bit changes from 1 to 0
				if (!(nIterate & 1 << i) && currentBit == 1)
					currentBit = 0;
			}
		}

		//calculate running average
		totRun += nCount;
		average = totRun / nIterate;

		//reset run counters for next value
		currentBit = 0;
		nCount = 0;
	}

	//display average to user
	printf("Average number of runs: %.2f", average);

	exit(EXIT_SUCCESS);
}