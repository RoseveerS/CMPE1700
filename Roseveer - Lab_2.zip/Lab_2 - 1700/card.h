//*****************************
// Roseveer Salh - 200463801
//*****************************
#pragma once

#include <stdio.h>
#include <stdlib.h>

//define different suits in deck
typedef enum 
{
	Hearts = 1, Diamonds, Clubs, Spades
}Suit;

//define different values in deck
typedef enum 
{
	Two = 2, Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, Ace
}Value;

//every card within deck will have a suit, value, and corresponding name
typedef struct 
{
	Suit suit;
	Value value;
	char* suitString;
	char* valueString;
}Card;

//deck of cards
Card deck[52];

//strings to print suit
static const char suitArray[5][9] = { "", "Hearts", "Diamonds", "Clubs", "Spades" };

//strings to print values
static const char valueArray[15][6] = { "", "", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace" };

//creates deck
void MakeDeck();

//shuffles deck
void Shuffle();

