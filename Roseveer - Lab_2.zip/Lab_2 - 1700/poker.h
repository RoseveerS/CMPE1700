#pragma once

#include <stdio.h>
//*****************************
// Roseveer Salh - 200463801
//*****************************
#include <stdlib.h>
#include "card.h"

//enum for all possible poker hands
typedef enum 
{
	Pair = 1, TwoPair, ThreeOfAKind, Straight, Flush, FullHouse, FourOfAKind, StraightFlush

}PokerHands;

//each player gets a 5 card hand with a poker hand and a high card,
//player number to determine who won
typedef struct 
{			   
	Card playerHand[5];
	int pokerHand;
	int highValue;
	int playerNum;

}PlayerHand;

//4 players in poker game
PlayerHand Players[4];

//strings to print poker hand
static const char handValueArray[9][20] =
{ "", "Pair", "Two Pair","Three of a Kind","Straight", "Flush","Full House","Four of a Kind","Straight Flush" };

//deal 5 cards to each player
void DealCards();

//display player cards to console
void ShowCards(int player);

//sort player hand
void SortHand(int player);

//evaluate player hand to determine what kind of poker hand they have
void EvaluateHand(int player);

//get poker hand from calling EvaluateHand
void PokerHand(int player);

//determine the winner(s) of the game
void Winner();