//*****************************
// Roseveer Salh - 200463801
//*****************************
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "card.h"

//Creates the deck of 52 cards, with one of each value for all of the suits
void MakeDeck()
{
	int nIterate = 0;		//iterate through deck whenever a card is added

	//for loop to iterate through each suit
	for (Suit suit = Hearts; suit <= Spades; suit++)
	{
		//for loop to iterate through each value
		for (Value value = Two; value <= Ace; value++)
		{
			//add a card to the deck of each suit and value with the assigned names
			deck[nIterate] = (Card){ suit, value, suitArray[suit], valueArray[value] };
			nIterate++;
		}
	}
}

//shuffles deck into a random order
void Shuffle()
{
	Card temp1;		//store card 1 in temp var
	Card temp2;		//store card 2 in temp var
	int rng;		//randomly selected location of card
	int nIterate;	//iterate through deck

	//iterate through the deck in reverse order, so the random card is limited to the cards that havent been chosen yet
	for (nIterate = 51; nIterate > 0; nIterate--)
	{
		//get a random location
		srand(time(0));
		rng = rand() % (nIterate);

		//store the cards to swap
		temp1 = deck[nIterate];
		temp2 = deck[rng];

		//swap both of the cards
		deck[nIterate] = temp2;
		deck[rng] = temp1;
	}
}