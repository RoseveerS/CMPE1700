//*****************************
// Roseveer Salh - 200463801
//*****************************
#include <stdio.h>
#include <stdlib.h>
#include "card.h"
#include "poker.h"

//deals 5 cards to each player and assigns them a number from 1 - 4
void DealCards()
{
	int nIterate = 0;		//iterate through hand
	int player = 0;			//player number
	int cards = 0;			//cards to hand out

	//assign a player number
	for (player = 0; player < 4; player++)
	{
		Players[player].playerNum = player + 1;
	}

	//deal 5 cards to each player
	for (cards = 0; cards < 5; cards++)
	{
		for (player = 0; player < 4; player++)
		{
			Players[player].playerHand[cards] = deck[nIterate];
			nIterate++;
		}
	}
}

//displays player hands to console
void ShowCards(int player)
{
	int cards = 0;		//card in player hand

	printf("Player %d \n======== \n", Players[player].playerNum);

	//iterate through player hand
	for (cards = 0; cards < 5; cards++)
	{
		//display card in player hand from value array and suit array
		printf("%s of %s\n", Players[player].playerHand[cards].valueString, Players[player].playerHand[cards].suitString);
	}

	printf("\n");
}

//sort player hands from smallest to greatest.
void SortHand(int player)
{
	int card1 = 0;		//card 1 in player hand
	int card2 = 0;		//card 2 in player hand

	//iterate through player hand
	for (card1 = 0; card1 < 5; card1++)
	{
		//check card 1 with hand
		for (card2 = card1 + 1; card2 < 5; card2++)
		{
			//if card 1 has a greater value than card 2
			if (Players[player].playerHand[card1].value > Players[player].playerHand[card2].value)
			{
				//swap card 1 and card 2
				Card temp1 = Players[player].playerHand[card1];
				Card temp2 = Players[player].playerHand[card2];
				Players[player].playerHand[card1] = temp2;
				Players[player].playerHand[card2] = temp1;
			}
		}
	}
}

//evaluate players hand to determine the value of their hand
void EvaluateHand(int player)
{
	int cardMatch1 = 1;			//the number of cards that have the same value in the first set of matches
	int valueMatch1 = 0;		//stores the value of matching cards, used to prevent counting 2 pairs as a three of a kind
	int cardMatch2 = 1;			//the number of cards that have the same value in the second set of matches
	int valueMatch2 = 0;		//stores the value of the second set of matching cards
	int numPairs = 0;			//counts the number of pairs of different values
	int flushCount = 1;			//the number of cards that are all the same suit
	int straightCount = 1;		//the number of cards in a row that are sequential in value
	int card1 = 0;				//card 1 in player hand
	int card2 = 0;				//card 2 in player hand

	// Find Matching Cards

	//iterate through the players hand
	for (card1 = 0; card1 < 5; card1++)
	{
		//check card 1 with card 2
		for (card2 = card1 + 1; card2 < 5; card2++)
		{
			//if card 1 matches card 2 in value, and no matches have been found yet
			if (Players[player].playerHand[card1].value == Players[player].playerHand[card2].value && valueMatch1 == 0)
			{
				//count the match, store the value of matching cards
				cardMatch1++;
				numPairs++;
				valueMatch1 = Players[player].playerHand[card1].value;
			}

			//if 2 cards match, and have the same value as the first match, count it
			else if ((Players[player].playerHand[card1].value == Players[player].playerHand[card2].value) && (Players[player].playerHand[card1].value == valueMatch1))
			{
				cardMatch1++;
			}

			//if 2 cards match, and have a different value as the first match
			else if ((Players[player].playerHand[card1].value == Players[player].playerHand[card2].value) && (Players[player].playerHand[card1].value != valueMatch1))
			{
				//count as match # 2, store the value of matching cards, increment the total number of pairs
				valueMatch2 = Players[player].playerHand[card1].value;
				cardMatch2++;
				numPairs++;
			}
		}
	}

	//Assign Player a Poker Hand Value

	//if player has a single set of matching cards
	if (numPairs == 1)
	{
		//assign player a high card based on the matching cards value
		Players[player].highValue = valueMatch1;

		//check if they have pair, triple or quad match, assign hand value accordingly
		switch (cardMatch1)
		{
		case 2:
			Players[player].pokerHand = Pair;
			break;
		case 4:
			Players[player].pokerHand = ThreeOfAKind;
			break;
		case 7:
			Players[player].pokerHand = FourOfAKind;
			break;
		}
	}

	//if player has 2 sets of matching cards
	else if (numPairs == 2)
	{
		//get the value of the higher match and assign it as high card
		if (valueMatch1 > valueMatch2)
			Players[player].highValue = valueMatch1;
		else
			Players[player].highValue = valueMatch2;

		//if player has 2 pairs
		if (cardMatch1 == 2 && cardMatch2 == 2)
			Players[player].pokerHand = TwoPair;

		//if player has full house
		else if (cardMatch1 > 2 || cardMatch2 > 2)
			Players[player].pokerHand = FullHouse;
	}

	//Determine If Player Has a Flush

	//iterate through the players hand
	for (card1 = 0; card1 < 4; card1++)
	{
		//check that both cards have the same suit
		if (Players[player].playerHand[card1].suit == Players[player].playerHand[card1 + 1].suit)
			flushCount++;
	}

	//assign player a hand value of flush if they have one
	if (flushCount == 5)
		Players[player].pokerHand = Flush;

	//Determine If Player Has a Straight Flush Or a Straight

	//iterate through the players hand
	for (card1 = 0; card1 < 4; card1++)
	{
		//check if the value of each card is one greater than the last
		if (Players[player].playerHand[card1].value + 1 == Players[player].playerHand[card1 + 1].value)
			straightCount++;
	}

	//assign the player a value of straight if they have it
	if (straightCount == 5)
	{
		//if player already has a flush, assign them straightflush hand value
		if (Players[player].pokerHand == Flush)
			Players[player].pokerHand = StraightFlush;

		//otherwise assign them a straight
		else
			Players[player].pokerHand = Straight;
	}
}

//check all player hands and get highest card value
void PokerHand(int player)
{
	//initialize poker hand value and high card value to zero
	Players[player].pokerHand = 0;
	Players[player].highValue = 0;

	//evaluate each player hand using EvaluateHand method
	EvaluateHand(player);

	//if player has no high card value assigned yet, use last card in hand
	if (Players[player].highValue == 0)
		Players[player].highValue = Players[player].playerHand[4].value;
}

//check all poker hand values, and find a winner
void Winner()
{
	PlayerHand temp1;	//temp 1 for storing and swapping players
	PlayerHand temp2;	//temp 2 for storing and swapping players
	int player1 = 0;	//iterate through players from player 1
	int player2 = 0;	//compare player 1 to rest of players

	//Sort Players By Poker Hand Value
	
	//iterate through each player
	for (player1 = 0; player1 < 4; player1++)
	{
		//compare player 1 to all other players
		for (player2 = player1 + 1; player2 < 4; player2++)
		{
			//if player p has a greater hand value than player i
			if (Players[player1].pokerHand > Players[player2].pokerHand)
			{
				//swap players p and i in the player array
				temp1 = Players[player1];
				temp2 = Players[player2];
				Players[player1] = temp2;
				Players[player2] = temp1;
			}
			//if a tie is found, check the players high cards
			if (Players[player1].pokerHand == Players[player2].pokerHand)
			{
				//if player p has a higher high card, swap them in the array
				if (Players[player1].highValue > Players[player2].highValue)
				{
					temp1 = Players[player1];
					temp2 = Players[player2];
					Players[player1] = temp2;
					Players[player2] = temp1;
				}
			}
		}
	}

	//Determine Winner

	printf("Winner(s) \n=========");

	//if there are no ties, the last player in the array wins
	if (Players[3].pokerHand > Players[2].pokerHand)
		printf("\nPlayer %d wins with a %s!\n", Players[3].playerNum, handValueArray[Players[3].pokerHand]);

	//check if there is a tie by hand value, if there is, determine winner by high card
	else if (Players[3].pokerHand == Players[2].pokerHand)
	{
		//if players[3] has a higher high card, they win
		if (Players[3].highValue > Players[2].highValue)
			printf("\nPlayer %d wins with a %s!\n", Players[3].playerNum, handValueArray[Players[3].pokerHand]);

		//if the high cards are a tie, determine how many other players have the same high card
		else if (Players[3].highValue == Players[2].highValue)
		{
			//if players[2/1] have the same high card
			if (Players[2].highValue == Players[1].highValue)
			{
				//if all players have the same high card, they all win
				if (Players[1].highValue == Players[0].highValue)
					printf("\All Players win with a %s!\n", handValueArray[Players[3].pokerHand]);

				//if only 3 players have the same high card, those 3 win
				else
					printf("\nPlayer %d, %d and %d win with a %s!\n", Players[3].playerNum, Players[2].playerNum, Players[1].playerNum, handValueArray[Players[3].pokerHand]);
			}
			//if only 2 players have the same high card, both of them win
			else
				printf("\nPlayer %d and %d both win with a %s!\n", Players[3].playerNum, Players[2].playerNum, handValueArray[Players[3].pokerHand]);
		}
	}
}

