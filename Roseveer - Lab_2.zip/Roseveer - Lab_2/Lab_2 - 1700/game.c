//*****************************
// Roseveer Salh - 200463801
//*****************************
#include <stdio.h>
#include <stdlib.h>
#include "card.h"
#include "poker.h"

int main()
{
	int player = 0;		//iterate through players

	//create deck of 52 cards
	MakeDeck();

	//shuffle deck
	Shuffle();

	//deal hands to players
	DealCards();

	//iterate through players
	for (player = 0; player < 4; player++)
	{
		//sort hand of player
		SortHand(player);

		//display hand of player
		ShowCards(player);

		//determine poker hand value of player
		PokerHand(player);
	}

	//determine winner
	Winner();
}